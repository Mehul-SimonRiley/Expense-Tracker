"use client";

import React from "react";

export default function Page() {
  return (
    <div>
      <h1>Welcome to the Expense Tracker!</h1>
      <p>The login page has been temporarily disabled.</p>
    </div>
  );
}